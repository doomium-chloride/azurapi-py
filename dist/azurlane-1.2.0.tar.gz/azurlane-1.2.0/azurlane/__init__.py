__version__ = '1.0.3'
__authors__ = 'Noel, Spimy'

from .updater import AzurApiUpdater
from .azurapi import AzurAPI
from .utils import *